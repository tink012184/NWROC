var GenEmailBtn = document.querySelector(".GenEmail");


GenEmailBtn.addEventListener("click", function(event) {

Update();

SendMail();


}

);

function Update() {

    MA = (document.getElementById("MA").value)
	HUB = (document.getElementById("HubHub").value)
	NODE = (document.getElementById("Node").value)
    Score = (document.getElementById("Score").value)
    Alarm = (document.getElementById("Alarm").value)
	LH = (document.getElementById("LH").value)
    IVR = (document.getElementById("IVR").value)
    TC = (document.getElementById("TC").value)
    Repeat = (document.getElementById("Repeat").value)
    MT = (document.getElementById("Tech").value)
    Link = (document.getElementById("Link").value)
    Synopsis = (document.getElementById("Synopsis").value)

    document.getElementById("Email").innerHTML = MA + " - High Demand/REACT Node - Hub: " + HUB + " - Node: " + NODE + "\n\nMA: " + MA + "\nHub: " + HUB + "\nNode: " + NODE + "\nHigh Demand Score: " + Score + "\nAlarm Count: " + Alarm + "\nLink to Lighthouse Workorder: " + LH + "\nIVR Count: " + IVR + "\nTC Count: " + TC + "\nHighest Repeat in Node: " + Repeat + "\nMT Assigned: " + MT + "\nLink to Lighthouse Workorder: " + Link +"\r\r" + "\n\n" + "\n\nROC Synopsis: " + Synopsis + "\n\nSupporting Screen Shots\n[Set Screen 3 to 1 Week]\n[Work Order History]\n[Alarm History]\n[Pathtrack(spectrum or mactrak)]\n[Lighthouse Map Showing Impairments]\n[Continuity Alarm History]";

}

function HubLoad(value){
	
	MA=document.getElementById("MA").value;
document.getElementById("HubHub").innerHTML = "<option></option>";

	if (MA == "Mountain States") {
			var HubOptions = "";
			for (MAid in HubsByMA[value]) {
				HubOptions += "<option>" + HubsByMA[value][MAid] + "</option>";
				}
			document.getElementById("HubHub").innerHTML = HubOptions;
	}

	if (MA == "Pacific Northwest") {

			var HubOptions = "";
			for (MAid in HubsByMA[value]) {
				HubOptions += "<option>" + HubsByMA[value][MAid] + "</option>";
				}
			document.getElementById("HubHub").innerHTML = HubOptions;
	}

	if (MA == "Sierra Nevada") {		

			var HubOptions = "";
			for (MAid in HubsByMA[value]) {
				HubOptions += "<option>" + HubsByMA[value][MAid] + "</option>";
				}
				document.getElementById("HubHub").innerHTML = HubOptions;
	}
	
}


function TechLoad(value){
	
	HubHub=document.getElementById("HubHub").value;
document.getElementById("Tech").innerHTML = "<option></option>";

	if (HubHub == "ALMSCO33564 - ALAMOSA") {
			var TechOptions = "";
			for (Techid in TechsByMA[value]) {
				TechOptions += "<option>" + TechsByMA[value][Techid] + "</option>";
				}
			document.getElementById("Tech").innerHTML = TechOptions;
	}

	if (HubHub == "ANCNMT33577 - ANACONDA") {

			var TechOptions = "";
			for (Techid in TechsByMA[value]) {
				TechOptions += "<option>" + TechsByMA[value][Techid] + "</option>";
				}
			document.getElementById("Tech").innerHTML = TechOptions;
	}

	if (HubHub == "BASNWY33614 - BASIN") {		

			var TechOptions = "";
			for (Techid in TechsByMA[value]) {
				TechOptions += "<option>" + TechsByMA[value][Techid] + "</option>";
				}
				document.getElementById("Tech").innerHTML = TechOptions;
	}
	
}

function DLTo() {
    EmailWho[value] = (document.getElementById("Tech").value)

}


function SendMail () {

    MA = (document.getElementById("MA").value)
	HUB = (document.getElementById("HubHub").value)
	NODE = (document.getElementById("Node").value)
    Score = (document.getElementById("Score").value)
    Alarm = (document.getElementById("Alarm").value)
	LH = (document.getElementById("LH").value)
    IVR = (document.getElementById("IVR").value)
    TC = (document.getElementById("TC").value)
    Repeat = (document.getElementById("Repeat").value)
    MT = (document.getElementById("Tech").value)
    Link = (document.getElementById("Link").value)
    Synopsis = (document.getElementById("Synopsis").value)
    EmailWho = EmailWho[value]
 




let mailTo = "";
	
mailTo = "mailto:" + "ROC-NW@charter.com;" + EmailWho + "?cc=" + "DL-Field-Ops-Eng-ROC-NW-ROC-IV@charter.com; DL-Field-Ops-Eng-ROC-NW-Mgmt@charter.com" + "&subject="+ encodeURIComponent(MA + " - High Demand/REACT Node - Hub: " + HUB + " - Node: " + NODE) + "&body="+ encodeURIComponent("MA: " + MA + "\nHub: " + HUB + "\nNode: " + NODE + "\nHigh Demand Score: " + Score + "\nAlarm Count: " + Alarm + "\nLink to Lighthouse Workorder: " + LH + "/nIVR Count: " + IVR + "\nTC Count: " + TC + "\nHighest Repeat in Node: " + Repeat + "\nMT Assigned: " + MT + "\nLink to Lighthouse Workorder: " + Link +"\r\r" + "\n\n") + encodeURIComponent("\n\nROC Synopsis" + Synopsis) + encodeURIComponent("\n\nSupporting Screen Shots\n[Set Screen 3 to 1 Week]\n[Work Order History]\n[Alarm History]\n[Pathtrack(spectrum or mactrak)]\n[Lighthouse Map Showing Impairments]\n[Continuity Alarm History]");

document.location.href = mailTo;

}